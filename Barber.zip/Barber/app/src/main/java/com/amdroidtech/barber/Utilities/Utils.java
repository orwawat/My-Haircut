package com.amdroidtech.barber.Utilities;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class Utils {


    /*
* Calculate distance between two points in latitude and longitude taking
* into account height difference. If you are not interested in height
* difference pass 0.0. Uses Haversine method as its base.
*
* lat1, lon1 Start point lat2, lon2 End point el1 Start altitude in meters
* el2 End altitude in meters
* @returns Distance in Meters
*/
    public static double CalculateDistance(double lat1, double lat2, double lon1,
                                           double lon2, double el1, double el2) {

        final int R = 6371; // Radius of the earth

        Double latDistance = Math.toRadians(lat2 - lat1);
        Double lonDistance = Math.toRadians(lon2 - lon1);
        Double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        Double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c * 1000; // convert to meters

        double height = el1 - el2;

        distance = Math.pow(distance, 2) + Math.pow(height, 2);
        return Math.sqrt(distance);
    }


    public static boolean checkGps(Context context) {
        LocationManager manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        return manager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }


    /**
     * Check the Wifi  is connected or Not.
     *
     * @param context
     * @return
     */
    public static boolean checkWifi(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        return wifi != null && wifi.isConnected();
    }


    /**
     * to check if there's internet connection available
     **/
    public static boolean checkInternet(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    public static void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }



    public static ArrayList<String> getTypes() {
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Business Services");
        arrayList.add("Public Place");
        arrayList.add("Personal");
        return arrayList;
    }


    /**
     * Pass arraylist then check it then fill it then return it , 7aga Gen :D .
     *
     * @param type
     * @return
     */
    public static ArrayList<String> getCategoriesByType(String type) {
        ArrayList<String> arrayList = new ArrayList<>();
        switch (type) {
            case "Business Services":
                fillBusinessList(arrayList);
                break;

            case "Public Place":
                fillPublicList(arrayList);
                break;

            case "Personal":
                fillPersonalList(arrayList);
                break;
        }
        return arrayList;
    }


    public static int getTypeByName(String name) {
        switch (name) {
            case "Business Services":
                return 2;

            case "Public Place":
                return 4;

            case "Personal":
                return 1;
        }
        return 0;
    }


    public static String getTypeNameFromServer(String serverName) {
        if (TextUtils.isEmpty(serverName)) {
            return "";
        }
        switch (serverName) {
            case "business":
                return "Business Services";

            case "public":
                return "Public Place";

            case "personal":
                return "Personal";
        }
        return "";
    }


    private static void fillPersonalList(ArrayList<String> arrayList) {
        arrayList.add("Home");
        arrayList.add("School");
        arrayList.add("University");
        arrayList.add("Work");
    }


    private static void fillPublicList(ArrayList<String> arrayList) {
        arrayList.add("Attractions/Things to Do");
        arrayList.add("Cinema");
        arrayList.add("Club");
        arrayList.add("Concert Venue");
        arrayList.add("Government Organisation");
        arrayList.add("Landmark");
        arrayList.add("Library");
        arrayList.add("Museum/Art Gallery");
        arrayList.add("Non-Government Organisation (NGO)");
        arrayList.add("Park/Garden");
        arrayList.add("Political Organisation");
        arrayList.add("Religious Mosque/Church");
        arrayList.add("School");
        arrayList.add("Univercity");
    }


    private static void fillBusinessList(ArrayList<String> arrayList) {
        arrayList.add("Airport");
        arrayList.add("Arts/Entertainment/Nightlife");
        arrayList.add("Automotive");
        arrayList.add("Bank/Financial Services");
        arrayList.add("Chemicals");
        arrayList.add("Cinema");
        arrayList.add("Club");
        arrayList.add("Computers/Technology");
        arrayList.add("Consulting/Business Services");
        arrayList.add("Doctor");
        arrayList.add("Education");
        arrayList.add("Energy/Utility");
        arrayList.add("Engineering/Construction");
        arrayList.add("Event Planning/Event Services");
        arrayList.add("Farming/Agriculture");
        arrayList.add("Food/Beverages");
        arrayList.add("Health/Medical/Farmacy");
        arrayList.add("Hospital/Clinic");
        arrayList.add("Hotel");
        arrayList.add("Industrials");
        arrayList.add("Insurance company");
        arrayList.add("Internet/Software");
        arrayList.add("Lawyer");
        arrayList.add("Library");
        arrayList.add("Media/News/Publishing");
        arrayList.add("Mining/Materials");
        arrayList.add("Museum/Art Gallery");
        arrayList.add("Non-Government Organisation (NGO)");
        arrayList.add("Outdoor Gear/Sporting Goods");
        arrayList.add("Pet Services");
        arrayList.add("Political Organisation");
        arrayList.add("Property");
        arrayList.add("Pub/bar");
        arrayList.add("Restaurant/Cafe");
        arrayList.add("Retail and Consumer Merchandise");
        arrayList.add("School");
        arrayList.add("Shopping/Retail");
        arrayList.add("Spas/Beauty/Personal Care");
        arrayList.add("Sports/Recreation/Activities");
        arrayList.add("Telecommunication");
        arrayList.add("Tours/Sightseeing");
        arrayList.add("Transport/Freight");
        arrayList.add("Travel/Leisure");
        arrayList.add("Univercity");
    }


    public static String SHA1(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        md.update(text.getBytes("iso-8859-1"), 0, text.length());
        byte[] sha1hash = md.digest();
        return convertToHex(sha1hash);

    }

    public static String convertToHex(byte[] data) {
        StringBuilder buf = new StringBuilder();
        for (byte b : data) {
            int halfbyte = (b >>> 4) & 0x0F;
            int two_halfs = 0;
            do {
                buf.append((0 <= halfbyte) && (halfbyte <= 9) ? (char) ('0' + halfbyte) : (char) ('a' + (halfbyte - 10)));
                halfbyte = b & 0x0F;
            } while (two_halfs++ < 1);
        }
        return buf.toString();
    }


    public static double roundDouble(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    //used to hide and show fab
    public interface FabCallback {
        public void showFab();
        public void hideFab();
    }

    //communicate between fragments
    public interface FragmentSwitchInterface {
        void fragmentBecameVisible();
    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    /** return sort base saved on shared preference**/
    public static String getPreferredSearchDistance(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getString("search_distance","35");
    }

    /** return sort base saved on shared preference**/
    public static String getPreferredHomeFeedsArea(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getString("feeds_distance","15");
    }

    // return if main show case is finished
    public static boolean getPreferredShowCase1(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getBoolean("main_show_case1",false);
    }
    public static void putPreferredShowCase1(Context context, boolean b) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        prefs.edit().putBoolean("main_show_case1",b).apply();
    }

    // return if main show case is finished
    public static boolean getPreferredShowCase2(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getBoolean("main_show_case2",false);
    }
    public static void putPreferredShowCase2(Context context, boolean b) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        prefs.edit().putBoolean("main_show_case2",b).apply();
    }
    // return if main show case is finished
    public static boolean getPreferredShowCase3(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getBoolean("main_show_case3",false);
    }
    public static void putPreferredShowCase3(Context context, boolean b) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        prefs.edit().putBoolean("main_show_case3",b).apply();
    }
    // return if main show case is finished
    public static boolean getPreferredShowCase4(Context context) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        return prefs.getBoolean("main_show_case4",false);
    }
    public static void putPreferredShowCase4(Context context, boolean b) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(context);
        prefs.edit().putBoolean("main_show_case4",b).apply();
    }


}
