package com.amdroidtech.barber.Utilities;


import java.util.regex.Pattern;

/**
 * this is class represent constant in app
 */
public class Constants {

    //on activity result codes
    public static int RC_GOOGLE_SIGN_IN = 1;

    public static String BARBER = "barber";
    public static String CUSTOMER = "customer";

    //validation patterns
    public static final Pattern PASSWORD_PATTERN = Pattern
            .compile("[a-zA-Z0-9]{1,250}");
    public static final Pattern EMAIL_PATTERN = Pattern
            .compile("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
    public static final Pattern PHONE_PATTERN = Pattern
            .compile("[0-9]{1,250}");

    public static final String[] CATEGORY_DATA = {"Select Category","Home tools","Electrical", "Tool and diy",
            "Garden Equipment", "Baby and Kids Gear", "Sports and Travel","Clothing","Furniture","Other"};

    public static final String[] PRICE_DATA = {"Free (I want it back)","Sale (I don't need it any more)","Rent (it's Expensive)"};

    public static final String[] PRICE_TYPE_DATA = {"Day","hour"};

    /*
      Logging flag
     */
    public static final boolean LOGGING = false;

    /*
      Your imgur client id. You need this to upload to imgur.

      More here: https://api.imgur.com/
     */
    public static final String MY_IMGUR_CLIENT_ID = "e83fa70d13f28d4";

    /*
      Client Auth
     */
    public static String getClientAuth() {
        return "Client-ID " + MY_IMGUR_CLIENT_ID;
    }

    public static final String DATABASE_NAME = "aldoraRedSea";

}
